package com.glasshome.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

/** Иконка приложения с подписью и «пружинным» нажатием как в iOS. */
class AppCell(
    context: Context,
    val app: AppInfo,
    icon: Bitmap,
    iconSize: Int,
    showLabel: Boolean
) : LinearLayout(context) {
    val iconView = ImageView(context)

    init {
        val d = resources.displayMetrics.density
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding((3 * d).toInt(), 0, (3 * d).toInt(), 0)
        iconView.setImageBitmap(icon)
        addView(iconView, LinearLayout.LayoutParams(iconSize, iconSize))
        if (showLabel) {
            val tv = TextView(context)
            tv.text = app.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11.5f
            tv.isSingleLine = true
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER
            tv.setShadowLayer(4 * d, 0f, 1f * d, Color.argb(150, 0, 0, 0))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = (6 * d).toInt()
            addView(tv, lp)
        }
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }
}

/** Страница рабочего стола: сетка cols x rows. */
class GridPage(context: Context) : ViewGroup(context) {
    var cols = 4
    var rows = 6
    var sidePad = 0

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        setMeasuredDimension(w, h)
        val cw = (w - 2 * sidePad) / cols
        val ch = h / rows
        for (i in 0 until childCount) {
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val cw = (w - 2 * sidePad) / cols
        val ch = h / rows
        for (i in 0 until childCount) {
            val x = sidePad + (i % cols) * cw
            val y = (i / cols) * ch
            getChildAt(i).layout(x, y, x + cw, y + ch)
        }
    }
}

/** Библиотека приложений (последняя страница). */
class LibraryPage(context: Context) : FrameLayout(context) {
    val content = LinearLayout(context)

    init {
        content.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(context)
        sv.overScrollMode = OVER_SCROLL_NEVER
        sv.isVerticalScrollBarEnabled = false
        sv.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }
}

/** Стеклянная капсула: «Поиск» на первой странице, точки на остальных. */
class PageIndicator(context: Context, private val onSearch: () -> Unit) : FrameLayout(context) {
    private val dots = DotsView(context)

    init {
        addView(GlassView(context, -1f, 1.1f), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        addView(dots, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setOnClickListener { if (dots.position < 0.5f) onSearch() }
    }

    fun setCount(n: Int) { dots.count = n; dots.invalidate() }
    fun setPosition(p: Float) { dots.position = p; dots.invalidate() }

    private class DotsView(context: Context) : View(context) {
        var count = 1
        var position = 0f
        private val d = resources.displayMetrics.density
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        private val line = Paint(Paint.ANTI_ALIAS_FLAG)

        init {
            tp.color = Color.WHITE
            tp.textSize = 14f * d
            tp.typeface = Typeface.DEFAULT_BOLD
            line.color = Color.WHITE
            line.style = Paint.Style.STROKE
            line.strokeWidth = 1.8f * d
            line.strokeCap = Paint.Cap.ROUND
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val dotsA = position.coerceIn(0f, 1f)
            val searchA = 1f - dotsA
            val gap = 12f * d
            val startX = w / 2f - (count - 1) * gap / 2f
            if (dotsA > 0f) {
                for (i in 0 until count) {
                    val near = 1f - minOf(1f, abs(i - position))
                    p.color = Color.WHITE
                    p.alpha = ((0.4f + 0.6f * near) * 255f * dotsA).toInt()
                    c.drawCircle(startX + i * gap, h / 2f, 3.4f * d, p)
                }
            }
            if (searchA > 0f) {
                val text = "Поиск"
                val total = 20f * d + tp.measureText(text)
                val x0 = (w - total) / 2f
                val a = (255 * searchA).toInt()
                line.alpha = a
                tp.alpha = a
                c.drawCircle(x0 + 6f * d, h / 2f - 1.5f * d, 5f * d, line)
                c.drawLine(x0 + 10f * d, h / 2f + 2.5f * d, x0 + 14f * d, h / 2f + 6.5f * d, line)
                c.drawText(text, x0 + 20f * d, h / 2f + 5f * d, tp)
            }
        }
    }
}
