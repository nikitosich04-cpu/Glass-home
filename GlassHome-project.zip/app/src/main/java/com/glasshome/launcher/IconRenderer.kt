package com.glasshome.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

/** Рисует иконки в стиле iOS 26: «жидкое стекло» или свой цвет. */
object IconRenderer {
    private val cache = LruCache<String, Bitmap>(500)

    @Synchronized
    fun get(app: AppInfo, style: Int, tint: Int, size: Int): Bitmap {
        val key = "${app.key}|$style|$tint|$size"
        cache.get(key)?.let { return it }
        val bmp = render(app.icon, style, tint, size)
        cache.put(key, bmp)
        return bmp
    }

    @Synchronized
    fun clear() = cache.evictAll()

    /** Суперэллипс — «непрерывный» скруглённый квадрат iOS. */
    fun squirclePath(l: Float, t: Float, r: Float, b: Float): Path {
        val n = 5.0
        val path = Path()
        val cx = (l + r) / 2.0
        val cy = (t + b) / 2.0
        val a = (r - l) / 2.0
        val h = (b - t) / 2.0
        val steps = 160
        for (i in 0..steps) {
            val th = 2.0 * PI * i / steps
            val c = cos(th)
            val s = sin(th)
            val x = cx + a * sign(c) * abs(c).pow(2.0 / n)
            val y = cy + h * sign(s) * abs(s).pow(2.0 / n)
            if (i == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
        }
        path.close()
        return path
    }

    private fun layerBitmap(d: Drawable?, size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        if (d == null) return b
        val off = (size * 0.25f).toInt()
        d.setBounds(-off, -off, size + off, size + off)
        d.draw(Canvas(b))
        return b
    }

    private fun plainBitmap(d: Drawable, size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val pad = (size * 0.11f).toInt()
        d.setBounds(pad, pad, size - pad, size - pad)
        d.draw(Canvas(b))
        return b
    }

    /** Доля непрозрачных пикселей в центре: если иконка «сплошная», силуэт из неё не сделать. */
    private fun opaqueRatio(b: Bitmap): Float {
        var hit = 0
        var total = 0
        val from = 0.15f
        val to = 0.85f
        for (iy in 0 until 12) for (ix in 0 until 12) {
            val x = ((from + (to - from) * ix / 11f) * (b.width - 1)).toInt()
            val y = ((from + (to - from) * iy / 11f) * (b.height - 1)).toInt()
            total++
            if (Color.alpha(b.getPixel(x, y)) > 200) hit++
        }
        return hit / total.toFloat()
    }

    private fun render(icon: Drawable, style: Int, tint: Int, size: Int): Bitmap {
        val s = size.toFloat()
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val shape = squirclePath(0f, 0f, s, s)

        var bgLayer: Bitmap? = null
        val fgLayer: Bitmap
        var monoLayer: Bitmap? = null
        if (icon is AdaptiveIconDrawable) {
            bgLayer = layerBitmap(icon.background, size)
            fgLayer = layerBitmap(icon.foreground, size)
            if (Build.VERSION.SDK_INT >= 33) {
                val m = icon.monochrome
                if (m != null) monoLayer = layerBitmap(m, size)
            }
        } else {
            fgLayer = plainBitmap(icon, size)
        }

        val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)

        if (style == Prefs.STYLE_GLASS) {
            if (bgLayer != null) {
                bmpPaint.alpha = 175
                c.drawBitmap(bgLayer, 0f, 0f, bmpPaint)
                bmpPaint.alpha = 255
            } else {
                fill.color = Color.argb(70, 255, 255, 255)
                c.drawRect(0f, 0f, s, s, fill)
            }
            fill.color = Color.argb(34, 255, 255, 255)
            c.drawRect(0f, 0f, s, s, fill)
            c.drawBitmap(fgLayer, 0f, 0f, bmpPaint)
            gloss(c, s, 120, 55)
        } else {
            val top = ColorUtils.blendARGB(tint, Color.WHITE, 0.28f)
            val bot = ColorUtils.blendARGB(tint, Color.BLACK, 0.12f)
            fill.shader = LinearGradient(0f, 0f, 0f, s, top, bot, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, s, s, fill)
            fill.shader = null
            val glyph = monoLayer ?: fgLayer
            if (opaqueRatio(glyph) > 0.8f) {
                // сплошная иконка: рисуем оригинал, подкрашенный выбранным цветом
                if (bgLayer != null) c.drawBitmap(bgLayer, 0f, 0f, bmpPaint)
                c.drawBitmap(fgLayer, 0f, 0f, bmpPaint)
                fill.color = Color.argb(110, Color.red(tint), Color.green(tint), Color.blue(tint))
                c.drawRect(0f, 0f, s, s, fill)
            } else {
                val gp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                gp.colorFilter = PorterDuffColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
                c.save()
                c.scale(0.84f, 0.84f, s / 2f, s / 2f)
                c.drawBitmap(glyph, 0f, 0f, gp)
                c.restore()
            }
            gloss(c, s, 80, 40)
        }

        // маска-суперэллипс с гладкими краями
        val mask = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(mask).drawPath(shape, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
        c.drawBitmap(mask, 0f, 0f, dstIn)

        // блестящая кромка
        val rim = Paint(Paint.ANTI_ALIAS_FLAG)
        rim.style = Paint.Style.STROKE
        rim.strokeWidth = s * 0.022f
        val hi = if (style == Prefs.STYLE_GLASS) 230 else 150
        rim.shader = LinearGradient(
            0f, 0f, s, s,
            intArrayOf(
                Color.argb(hi, 255, 255, 255), Color.argb(18, 255, 255, 255),
                Color.argb(18, 255, 255, 255), Color.argb(hi * 2 / 3, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.35f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        val inset = rim.strokeWidth / 2f
        c.drawPath(squirclePath(inset, inset, s - inset, s - inset), rim)
        return out
    }

    private fun gloss(c: Canvas, s: Float, topAlpha: Int, bottomAlpha: Int) {
        val p = Paint()
        p.shader = LinearGradient(
            0f, 0f, 0f, s * 0.55f,
            Color.argb(topAlpha, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, s, s * 0.6f, p)
        p.shader = LinearGradient(
            0f, s * 0.65f, 0f, s,
            Color.argb(0, 255, 255, 255), Color.argb(bottomAlpha, 255, 255, 255), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, s * 0.65f, s, s, p)
    }
}
