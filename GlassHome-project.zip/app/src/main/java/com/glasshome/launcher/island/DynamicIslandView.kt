package com.glasshome.launcher.island

import android.animation.ValueAnimator
import android.app.PendingIntent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.dynamicanimation.animation.FloatPropertyCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import kotlin.math.PI
import kotlin.math.sin

private const val MP = android.view.ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = android.view.ViewGroup.LayoutParams.WRAP_CONTENT

enum class Mode { IDLE, MEDIA_COMPACT, MEDIA_EXPANDED, NOTIFICATION, CHARGING }

class MediaInfo(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val playing: Boolean,
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val updateTime: Long = 0L,
    val speed: Float = 1f
)

class NotifInfo(val title: String, val text: String, val icon: Drawable?, val tap: PendingIntent?)

/**
 * Чёрная капсула Dynamic Island. Рисуется поверх всех окон в районе выреза камеры,
 * размеры меняются пружинной физикой (SpringAnimation), как в iOS.
 */
class DynamicIslandView(context: Context) : FrameLayout(context) {

    interface Host {
        fun resizeWindow(w: Int, h: Int, touchable: Boolean)
        fun onCompactTap()
        fun onExpandedTap()
        fun onNotificationTap()
        fun onMediaOpenApp()
        fun onMediaControl(cmd: Int) // 0 назад, 1 пауза/play, 2 вперёд
    }

    var host: Host? = null
    var media: MediaInfo? = null
    var notif: NotifInfo? = null
    var chargeLevel = 0
    var showIdle = true

    private val d = resources.displayMetrics.density
    private var idleW = 100f * d
    private var idleH = 30f * d
    private var screenW = resources.displayMetrics.widthPixels.toFloat()
    private val margin = (14 * d).toInt()

    var curW = idleW
    var curH = idleH
    private var mode = Mode.IDLE
    private var layer: View? = null
    private var winW = 0
    private var winH = 0
    private var downY = 0f

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()

    private val wProp = object : FloatPropertyCompat<DynamicIslandView>("islandW") {
        override fun getValue(o: DynamicIslandView): Float = o.curW
        override fun setValue(o: DynamicIslandView, value: Float) { o.curW = value; o.invalidate() }
    }
    private val hProp = object : FloatPropertyCompat<DynamicIslandView>("islandH") {
        override fun getValue(o: DynamicIslandView): Float = o.curH
        override fun setValue(o: DynamicIslandView, value: Float) { o.curH = value; o.invalidate() }
    }
    private val springW = SpringAnimation(this, wProp)
        .setSpring(SpringForce().setStiffness(420f).setDampingRatio(0.66f))
    private val springH = SpringAnimation(this, hProp)
        .setSpring(SpringForce().setStiffness(420f).setDampingRatio(0.66f))

    private val shrinkRunnable = Runnable { applyWindowSize(mode, true) }

    init {
        setWillNotDraw(false)
        bg.color = Color.BLACK
    }

    fun setMetrics(idleWidth: Float, idleHeight: Float, screenWidth: Int) {
        idleW = idleWidth
        idleH = idleHeight
        screenW = screenWidth.toFloat()
        if (mode == Mode.IDLE) { curW = idleW; curH = idleH }
    }

    private fun sideSlot(): Float = idleH * 1.5f

    fun targetSize(m: Mode): Pair<Float, Float> = when (m) {
        Mode.IDLE -> Pair(idleW, idleH)
        Mode.MEDIA_COMPACT, Mode.CHARGING -> Pair(idleW + 2f * sideSlot(), idleH)
        Mode.MEDIA_EXPANDED -> Pair(minOf(screenW - 24f * d, 370f * d), 188f * d)
        Mode.NOTIFICATION -> Pair(minOf(screenW - 24f * d, 362f * d), idleH + 76f * d)
    }

    fun windowSizeFor(m: Mode): Pair<Int, Int> {
        val t = targetSize(m)
        return Pair(t.first.toInt() + 2 * margin, t.second.toInt() + margin)
    }

    private fun applyWindowSize(m: Mode, force: Boolean) {
        val (w, h) = windowSizeFor(m)
        if (!force && w < winW && h < winH) return
        winW = w
        winH = h
        host?.resizeWindow(w, h, m != Mode.IDLE)
    }

    // ------------------------------------------------------------ state

    fun show(newMode: Mode, animate: Boolean = true) {
        val same = newMode == mode && layer != null
        val (tw, th) = targetSize(newMode)
        mode = newMode
        removeCallbacks(shrinkRunnable)

        // окно растёт сразу, сжимается — после анимации
        val (ww, wh) = windowSizeFor(newMode)
        if (ww >= winW && wh >= winH) applyWindowSize(newMode, true)
        else {
            host?.resizeWindow(winW, winH, newMode != Mode.IDLE)
            postDelayed(shrinkRunnable, 520)
        }

        val newLayer = buildLayer(newMode)
        val old = layer
        layer = newLayer
        if (newLayer != null) {
            addView(newLayer, FrameLayout.LayoutParams(tw.toInt(), th.toInt(), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            if (animate && !same) {
                newLayer.alpha = 0f
                newLayer.animate().alpha(1f).setStartDelay(90).setDuration(200).start()
            }
        }
        if (old != null) {
            if (animate && !same) old.animate().alpha(0f).setDuration(110).withEndAction { removeView(old) }.start()
            else removeView(old)
        }

        val hide = newMode == Mode.IDLE && !showIdle
        animate().alpha(if (hide) 0f else 1f).setDuration(200).start()

        if (animate) {
            springW.animateToFinalPosition(tw)
            springH.animateToFinalPosition(th)
        } else {
            springW.cancel(); springH.cancel()
            curW = tw; curH = th
            invalidate()
        }
    }

    // ------------------------------------------------------------ draw / touch

    private fun radius(): Float = minOf(curH / 2f, 38f * d)

    private fun updateRect() {
        val l = (width - curW) / 2f
        rect.set(l, 0f, l + curW, curH)
    }

    override fun onDraw(canvas: Canvas) {
        updateRect()
        val r = radius()
        canvas.drawRoundRect(rect, r, r, bg)
    }

    override fun dispatchDraw(canvas: Canvas) {
        updateRect()
        val r = radius()
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        super.dispatchDraw(canvas)
        canvas.restore()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) downY = ev.y
        if (ev.actionMasked == MotionEvent.ACTION_UP &&
            downY - ev.y > 40 * d && (mode == Mode.NOTIFICATION || mode == Mode.MEDIA_EXPANDED)
        ) {
            host?.onExpandedTap()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    // ------------------------------------------------------------ layers

    private fun fl(w: Int, h: Int, gravity: Int): FrameLayout.LayoutParams =
        FrameLayout.LayoutParams(w, h, gravity)

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(context)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        t.isSingleLine = true
        t.ellipsize = TextUtils.TruncateAt.END
        if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        return t
    }

    private fun roundImage(radiusDp: Float): ImageView {
        val iv = ImageView(context)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, radiusDp * d)
            }
        }
        iv.clipToOutline = true
        return iv
    }

    private fun setArt(iv: ImageView, m: MediaInfo?) {
        val art = m?.art
        if (art != null) iv.setImageBitmap(art)
        else iv.setImageDrawable(
            GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(255, 45, 85), Color.rgb(94, 92, 230))
            )
        )
    }

    private fun buildLayer(m: Mode): View? = when (m) {
        Mode.IDLE -> null
        Mode.MEDIA_COMPACT -> compactMedia()
        Mode.MEDIA_EXPANDED -> expandedMedia()
        Mode.NOTIFICATION -> notification()
        Mode.CHARGING -> charging()
    }

    private fun compactMedia(): View {
        val tw = targetSize(Mode.MEDIA_COMPACT).first
        val slot = (tw - idleW) / 2f
        val f = FrameLayout(context)
        val sz = (idleH * 0.62f).toInt()
        val art = roundImage(5f)
        setArt(art, media)
        val alp = fl(sz, sz, Gravity.START or Gravity.CENTER_VERTICAL)
        alp.marginStart = ((slot - sz) / 2f).toInt()
        f.addView(art, alp)
        val ew = (16 * d).toInt()
        val elp = fl(ew, (14 * d).toInt(), Gravity.END or Gravity.CENTER_VERTICAL)
        elp.marginEnd = ((slot - ew) / 2f).toInt()
        f.addView(EqView(context, media?.playing == true), elp)
        f.setOnClickListener { host?.onCompactTap() }
        return f
    }

    private fun expandedMedia(): View {
        val f = FrameLayout(context)
        val art = roundImage(12f)
        setArt(art, media)
        val alp = fl((52 * d).toInt(), (52 * d).toInt(), Gravity.TOP or Gravity.START)
        alp.leftMargin = (18 * d).toInt(); alp.topMargin = (16 * d).toInt()
        f.addView(art, alp)
        art.setOnClickListener { host?.onMediaOpenApp() }

        val elp = fl((22 * d).toInt(), (18 * d).toInt(), Gravity.TOP or Gravity.END)
        elp.rightMargin = (24 * d).toInt(); elp.topMargin = (32 * d).toInt()
        f.addView(EqView(context, media?.playing == true), elp)

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding((20 * d).toInt(), 0, (20 * d).toInt(), 0)
        val title = tv(media?.title ?: "", 16f, Color.WHITE, true)
        val artist = tv(media?.artist ?: "", 14f, Color.argb(179, 255, 255, 255), false)
        col.addView(title)
        col.addView(artist)
        val pl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (6 * d).toInt())
        pl.topMargin = (10 * d).toInt()
        col.addView(ProgressLine(context, media), pl)

        val row = LinearLayout(context)
        row.gravity = Gravity.CENTER
        val gsz = (40 * d).toInt()
        val kinds = intArrayOf(0, if (media?.playing == true) 1 else 3, 2)
        for ((i, k) in kinds.withIndex()) {
            val g = GlyphView(context, k)
            g.setOnClickListener { host?.onMediaControl(i) }
            val glp = LinearLayout.LayoutParams(gsz, gsz)
            glp.marginStart = (18 * d).toInt(); glp.marginEnd = (18 * d).toInt()
            row.addView(g, glp)
        }
        val rlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (44 * d).toInt())
        rlp.topMargin = (8 * d).toInt()
        col.addView(row, rlp)

        val clp = fl(MP, WC, Gravity.TOP)
        clp.topMargin = (72 * d).toInt()
        f.addView(col, clp)
        f.setOnClickListener { host?.onExpandedTap() }
        return f
    }

    private fun notification(): View {
        val n = notif
        val f = FrameLayout(context)
        val icon = roundImage(10f)
        icon.setImageDrawable(n?.icon)
        val ilp = fl((40 * d).toInt(), (40 * d).toInt(), Gravity.TOP or Gravity.START)
        ilp.leftMargin = (18 * d).toInt(); ilp.topMargin = (idleH + 6 * d).toInt()
        f.addView(icon, ilp)

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        val title = tv(n?.title ?: "", 16f, Color.WHITE, true)
        val text = tv(n?.text ?: "", 14f, Color.argb(204, 255, 255, 255), false)
        text.isSingleLine = false
        text.maxLines = 2
        col.addView(title)
        col.addView(text)
        val clp = fl(MP, WC, Gravity.TOP)
        clp.leftMargin = (70 * d).toInt(); clp.rightMargin = (18 * d).toInt()
        clp.topMargin = (idleH + 6 * d).toInt()
        f.addView(col, clp)
        f.setOnClickListener { host?.onNotificationTap() }
        return f
    }

    private fun charging(): View {
        val tw = targetSize(Mode.CHARGING).first
        val slot = (tw - idleW) / 2f
        val f = FrameLayout(context)
        val bw = (24 * d).toInt()
        val blp = fl(bw, (12 * d).toInt(), Gravity.START or Gravity.CENTER_VERTICAL)
        blp.marginStart = ((slot - bw) / 2f).toInt()
        f.addView(BatteryView(context, chargeLevel), blp)
        val t = tv("$chargeLevel%", 13f, Color.rgb(48, 209, 88), true)
        val tlp = fl(WC, WC, Gravity.END or Gravity.CENTER_VERTICAL)
        tlp.marginEnd = (slot * 0.12f).toInt()
        f.addView(t, tlp)
        return f
    }
}

/** Анимированный эквалайзер. */
class EqView(context: Context, private val playing: Boolean) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f)

    init {
        p.color = Color.rgb(255, 69, 105)
        anim.duration = 900
        anim.repeatCount = ValueAnimator.INFINITE
        anim.interpolator = LinearInterpolator()
        anim.addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (playing) anim.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        anim.cancel()
    }

    override fun onDraw(c: Canvas) {
        val n = 4
        val gap = width * 0.12f
        val bw = (width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val t = if (playing) 0.5f + 0.5f * sin(2.0 * PI * (phase + i * 0.23f)).toFloat() else 0.2f
            val h = height * (0.25f + 0.75f * t)
            val x = i * (bw + gap)
            c.drawRoundRect(x, (height - h) / 2f, x + bw, (height + h) / 2f, bw / 2f, bw / 2f, p)
        }
    }
}

/** Кнопки плеера: 0 назад, 1 пауза, 2 вперёд, 3 play. */
class GlyphView(context: Context, private val kind: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init { p.color = Color.WHITE }

    private fun tri(c: Canvas, x: Float, y: Float, w: Float, h: Float, right: Boolean) {
        path.reset()
        if (right) { path.moveTo(x, y); path.lineTo(x + w, y + h / 2f); path.lineTo(x, y + h) }
        else { path.moveTo(x + w, y); path.lineTo(x, y + h / 2f); path.lineTo(x + w, y + h) }
        path.close()
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val u = s * 0.5f
        when (kind) {
            3 -> tri(c, cx - u * 0.38f, cy - u * 0.5f, u * 0.9f, u, true)
            1 -> {
                val bw = u * 0.28f
                c.drawRoundRect(cx - u * 0.45f, cy - u * 0.5f, cx - u * 0.45f + bw, cy + u * 0.5f, bw / 3f, bw / 3f, p)
                c.drawRoundRect(cx + u * 0.17f, cy - u * 0.5f, cx + u * 0.17f + bw, cy + u * 0.5f, bw / 3f, bw / 3f, p)
            }
            2 -> {
                tri(c, cx - u * 0.6f, cy - u * 0.4f, u * 0.8f, u * 0.8f, true)
                c.drawRect(cx + u * 0.28f, cy - u * 0.4f, cx + u * 0.46f, cy + u * 0.4f, p)
            }
            else -> {
                tri(c, cx - u * 0.2f, cy - u * 0.4f, u * 0.8f, u * 0.8f, false)
                c.drawRect(cx - u * 0.46f, cy - u * 0.4f, cx - u * 0.28f, cy + u * 0.4f, p)
            }
        }
    }
}

/** Полоска прогресса трека. */
class ProgressLine(context: Context, private val m: MediaInfo?) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 500) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); removeCallbacks(tick) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = Color.argb(64, 255, 255, 255)
        c.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        val info = m ?: return
        if (info.durationMs <= 0L) return
        var pos = info.positionMs.toFloat()
        if (info.playing) pos += (SystemClock.elapsedRealtime() - info.updateTime) * info.speed
        val frac = (pos / info.durationMs).coerceIn(0f, 1f)
        p.color = Color.WHITE
        c.drawRoundRect(0f, 0f, w * frac, h, h / 2f, h / 2f, p)
    }
}

/** Иконка батареи для состояния зарядки. */
class BatteryView(context: Context, private val level: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val body = w * 0.9f
        p.style = Paint.Style.STROKE
        p.strokeWidth = h * 0.12f
        p.color = Color.argb(150, 255, 255, 255)
        c.drawRoundRect(p.strokeWidth, p.strokeWidth, body, h - p.strokeWidth, h * 0.3f, h * 0.3f, p)
        p.style = Paint.Style.FILL
        c.drawRect(body + 1f, h * 0.35f, w, h * 0.65f, p)
        p.color = Color.rgb(48, 209, 88)
        val inner = (body - 4f * p.strokeWidth) * (level.coerceIn(0, 100) / 100f)
        c.drawRoundRect(
            2f * p.strokeWidth, 2f * p.strokeWidth, 2f * p.strokeWidth + inner,
            h - 2f * p.strokeWidth, h * 0.15f, h * 0.15f, p
        )
    }
}
