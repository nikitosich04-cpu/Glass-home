package com.glasshome.launcher.island

import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.content.ContextCompat
import com.glasshome.launcher.Prefs
import com.glasshome.launcher.R

/**
 * Держит оверлей Dynamic Island поверх всех приложений.
 * Событийная логика: уведомления, музыка (MediaSession), зарядка.
 */
class IslandService : Service(), DynamicIslandView.Host {

    companion object {
        @Volatile var instance: IslandService? = null

        fun start(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, IslandService::class.java)) } catch (e: Exception) { }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, IslandService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private var view: DynamicIslandView? = null
    private var lp: WindowManager.LayoutParams? = null

    private var media: MediaInfo? = null
    private var controller: MediaController? = null
    private var tempMode: Mode? = null
    private var expandedMedia = false
    private var msm: MediaSessionManager? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        attachView()
        reconnectMedia()
        ContextCompat.registerReceiver(
            this, powerReceiver, IntentFilter(Intent.ACTION_POWER_CONNECTED), ContextCompat.RECEIVER_EXPORTED
        )
        prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
        handler.removeCallbacksAndMessages(null)
        try { prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener) } catch (e: Exception) { }
        try { unregisterReceiver(powerReceiver) } catch (e: Exception) { }
        try { controller?.unregisterCallback(controllerCallback) } catch (e: Exception) { }
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
        view?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        view = null
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Dynamic Island", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "island")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Dynamic Island активен")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(1, n)
    }

    // ------------------------------------------------------------ window

    private data class Metrics(val idleW: Float, val idleH: Float, val top: Float)

    /** Размер и позиция капсулы подгоняются под вырез камеры (Honor 90 — по центру сверху). */
    private fun metrics(): Metrics {
        val d = resources.displayMetrics.density
        val cutH = if (prefs.cutoutH > 0f) prefs.cutoutH else 28f * d
        val baseH = (cutH * 0.85f + 8f * d).coerceIn(26f * d, 36f * d)
        val h = baseH * prefs.islandScale
        val w = h * 3.2f
        val cy = if (prefs.cutoutCy > 0f) prefs.cutoutCy else 18f * d
        val top = (cy - h / 2f + prefs.islandOffsetDp * d).coerceAtLeast(0f)
        return Metrics(w, h, top)
    }

    private fun attachView() {
        val v = DynamicIslandView(this)
        v.host = this
        v.showIdle = prefs.islandIdle
        val m = metrics()
        v.setMetrics(m.idleW, m.idleH, resources.displayMetrics.widthPixels)
        view = v
        val (w, h) = v.windowSizeFor(Mode.IDLE)
        val p = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = m.top.toInt()
        p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        p.title = "GlassIsland"
        lp = p
        wm.addView(v, p)
        v.show(Mode.IDLE, false)
    }

    private fun applyPrefs() {
        if (!prefs.islandEnabled) { stopSelf(); return }
        val v = view ?: return
        val p = lp ?: return
        val m = metrics()
        v.showIdle = prefs.islandIdle
        v.setMetrics(m.idleW, m.idleH, resources.displayMetrics.widthPixels)
        p.y = m.top.toInt()
        try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
        refresh()
    }

    override fun resizeWindow(w: Int, h: Int, touchable: Boolean) {
        val v = view ?: return
        val p = lp ?: return
        p.width = w
        p.height = h
        p.flags = if (touchable) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
    }

    // ------------------------------------------------------------ state machine

    private fun baseMode(): Mode = if (media?.playing == true) Mode.MEDIA_COMPACT else Mode.IDLE

    private val endTemp = Runnable { tempMode = null; refresh() }
    private val collapseMedia = Runnable { expandedMedia = false; if (tempMode == null) refresh() }

    private fun showTemp(mode: Mode, ms: Long) {
        handler.removeCallbacks(endTemp)
        handler.removeCallbacks(collapseMedia)
        expandedMedia = false
        tempMode = mode
        view?.show(mode, true)
        handler.postDelayed(endTemp, ms)
    }

    private fun refresh() {
        val v = view ?: return
        v.media = media
        val target = tempMode
            ?: if (expandedMedia && media != null) Mode.MEDIA_EXPANDED else baseMode()
        v.show(target, true)
    }

    override fun onCompactTap() {
        if (media == null) return
        expandedMedia = true
        refresh()
        handler.removeCallbacks(collapseMedia)
        handler.postDelayed(collapseMedia, 7000)
    }

    override fun onExpandedTap() {
        handler.removeCallbacks(endTemp)
        handler.removeCallbacks(collapseMedia)
        tempMode = null
        expandedMedia = false
        refresh()
    }

    override fun onNotificationTap() {
        sendPending(view?.notif?.tap)
        onExpandedTap()
    }

    override fun onMediaOpenApp() {
        val c = controller
        if (c != null) {
            val pi = c.sessionActivity
            if (pi != null) sendPending(pi)
            else packageManager.getLaunchIntentForPackage(c.packageName)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivity(it) } catch (e: Exception) { }
            }
        }
        onExpandedTap()
    }

    override fun onMediaControl(cmd: Int) {
        val t = controller?.transportControls ?: return
        when (cmd) {
            0 -> t.skipToPrevious()
            1 -> if (media?.playing == true) t.pause() else t.play()
            2 -> t.skipToNext()
        }
    }

    private fun sendPending(pi: PendingIntent?) {
        if (pi == null) return
        try {
            val opts = ActivityOptions.makeBasic()
            if (Build.VERSION.SDK_INT >= 34) {
                opts.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
            }
            pi.send(this, 0, null, null, null, null, opts.toBundle())
        } catch (e: Exception) { }
    }

    // ------------------------------------------------------------ events

    fun onNotification(title: String, text: String, pkg: String, tap: PendingIntent?) {
        handler.post {
            val v = view ?: return@post
            val icon = try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
            v.notif = NotifInfo(title.ifEmpty { text }, if (title.isEmpty()) "" else text, icon, tap)
            showTemp(Mode.NOTIFICATION, 5000)
        }
    }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val sc = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            view?.chargeLevel = if (sc > 0) lvl * 100 / sc else 0
            showTemp(Mode.CHARGING, 3500)
        }
    }

    // ------------------------------------------------------------ media

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pickController(list ?: emptyList())
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { updateMedia() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { updateMedia() }
    }

    /** Подключаем медиа-сессии; работает, когда выдан доступ к уведомлениям. */
    fun reconnectMedia() {
        try {
            val m = getSystemService(MediaSessionManager::class.java)
            msm = m
            val cn = ComponentName(this, IslandListener::class.java)
            try { m.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pickController(m.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // нет доступа к уведомлениям
        } catch (e: Exception) { }
    }

    private fun pickController(list: List<MediaController>) {
        val best = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            try { controller?.unregisterCallback(controllerCallback) } catch (e: Exception) { }
            controller = best
            best?.registerCallback(controllerCallback, handler)
        }
        updateMedia()
    }

    private fun updateMedia() {
        val c = controller
        if (c == null) media = null
        else {
            val md = c.metadata
            val ps = c.playbackState
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
            val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            media = if (title.isEmpty()) null else MediaInfo(
                title, artist, art,
                ps?.state == PlaybackState.STATE_PLAYING,
                md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
                ps?.position ?: 0L,
                ps?.lastPositionUpdateTime ?: 0L,
                ps?.playbackSpeed ?: 1f
            )
        }
        if (media == null) expandedMedia = false
        if (tempMode == null) refresh()
    }

    // ------------------------------------------------------------ demo

    /** Показать пример: зарядка → уведомление → музыка. */
    fun demo() {
        val v = view ?: return
        v.chargeLevel = 82
        showTemp(Mode.CHARGING, 2600)
        handler.postDelayed({
            v.notif = NotifInfo(
                "Glass Home", "Так будут выглядеть уведомления в Dynamic Island",
                applicationInfo.loadIcon(packageManager), null
            )
            showTemp(Mode.NOTIFICATION, 4200)
        }, 3000)
        handler.postDelayed({
            v.media = MediaInfo("Glass Home", "Пример трека", null, true, 200000L, 40000L, android.os.SystemClock.elapsedRealtime(), 1f)
            showTemp(Mode.MEDIA_EXPANDED, 5000)
        }, 7600)
    }
}
