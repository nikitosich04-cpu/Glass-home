package com.glasshome.launcher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

class Prefs(context: Context) {
    val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("glasshome", Context.MODE_PRIVATE)

    var iconStyle: Int
        get() = sp.getInt("icon_style", STYLE_GLASS)
        set(v) { sp.edit().putInt("icon_style", v).apply() }

    var tintColor: Int
        get() = sp.getInt("tint", Color.parseColor("#0A84FF"))
        set(v) { sp.edit().putInt("tint", v).apply() }

    var islandEnabled: Boolean
        get() = sp.getBoolean("island_on", true)
        set(v) { sp.edit().putBoolean("island_on", v).apply() }

    var islandIdle: Boolean
        get() = sp.getBoolean("island_idle", true)
        set(v) { sp.edit().putBoolean("island_idle", v).apply() }

    var islandScale: Float
        get() = sp.getFloat("island_scale", 1f)
        set(v) { sp.edit().putFloat("island_scale", v).apply() }

    var islandOffsetDp: Float
        get() = sp.getFloat("island_off", 0f)
        set(v) { sp.edit().putFloat("island_off", v).apply() }

    var dock: String?
        get() = sp.getString("dock", null)
        set(v) { sp.edit().putString("dock", v).apply() }

    var wallpaperRev: Int
        get() = sp.getInt("wall_rev", 0)
        set(v) { sp.edit().putInt("wall_rev", v).apply() }

    var cutoutCy: Float
        get() = sp.getFloat("cut_cy", 0f)
        set(v) { sp.edit().putFloat("cut_cy", v).apply() }

    var cutoutH: Float
        get() = sp.getFloat("cut_h", 0f)
        set(v) { sp.edit().putFloat("cut_h", v).apply() }

    var cutoutW: Float
        get() = sp.getFloat("cut_w", 0f)
        set(v) { sp.edit().putFloat("cut_w", v).apply() }

    fun signature(): String = "$iconStyle-$tintColor"

    companion object {
        const val STYLE_GLASS = 0
        const val STYLE_COLOR = 1
    }
}
