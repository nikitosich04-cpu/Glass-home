package com.glasshome.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable

data class AppInfo(
    val pkg: String,
    val cls: String,
    val label: String,
    val category: Int,
    val icon: Drawable
) {
    val key: String get() = "$pkg/$cls"
    val component: ComponentName get() = ComponentName(pkg, cls)
}

object AppRepo {
    @Suppress("DEPRECATION")
    fun load(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0).map { ri ->
            val ai = ri.activityInfo
            AppInfo(
                ai.packageName, ai.name, ri.loadLabel(pm).toString(),
                ai.applicationInfo.category, ri.loadIcon(pm)
            )
        }.sortedBy { it.label.lowercase() }
    }

    val groupOrder = listOf(
        "Общение", "Продуктивность", "Развлечения", "Фото и видео",
        "Игры", "Путешествия", "Чтение", "Утилиты"
    )

    fun group(a: AppInfo): String = when (a.category) {
        ApplicationInfo.CATEGORY_GAME -> "Игры"
        ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> "Развлечения"
        ApplicationInfo.CATEGORY_IMAGE -> "Фото и видео"
        ApplicationInfo.CATEGORY_SOCIAL -> "Общение"
        ApplicationInfo.CATEGORY_NEWS -> "Чтение"
        ApplicationInfo.CATEGORY_MAPS -> "Путешествия"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Продуктивность"
        else -> "Утилиты"
    }
}
