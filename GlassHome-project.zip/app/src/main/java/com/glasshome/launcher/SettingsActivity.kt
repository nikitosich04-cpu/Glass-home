package com.glasshome.launcher

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.WindowCompat
import com.glasshome.launcher.island.IslandService
import java.io.File

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_WALLPAPER = 11

class SettingsActivity : Activity() {

    private lateinit var prefs: Prefs
    private val refreshers = mutableListOf<() -> Unit>()
    private lateinit var previewRow: LinearLayout
    private lateinit var colorBox: LinearLayout
    private lateinit var segGlass: TextView
    private lateinit var segColor: TextView
    private var previewApps: List<AppInfo> = emptyList()

    private val dens: Float get() = resources.displayMetrics.density
    private fun dp(v: Number): Int = (v.toFloat() * dens).toInt()

    // ---------------------------------------------------------------- helpers

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    private fun glassBg(): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(22).toFloat()
        g.setColor(0x1AFFFFFF)
        g.setStroke(dp(1), 0x33FFFFFF)
        return g
    }

    private fun label(text: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun section(parent: LinearLayout, title: String): LinearLayout {
        val t = label(title.uppercase(), 12f, Color.argb(153, 255, 255, 255))
        t.letterSpacing = 0.08f
        parent.addView(t, lp(MATCH, WRAP, 6, 26, 0, 8))
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(14), dp(16), dp(14))
        card.background = glassBg()
        parent.addView(card, lp(MATCH, WRAP))
        return card
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val t = label(text, 15f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(13), dp(14), dp(13))
        val g = GradientDrawable()
        g.cornerRadius = dp(16).toFloat()
        g.setColor(if (primary) Color.rgb(10, 132, 255) else Color.argb(45, 255, 255, 255))
        t.background = g
        t.setOnClickListener { onClick() }
        return t
    }

    private fun switchRow(card: LinearLayout, text: String, initial: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(label(text, 15f), LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = initial
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        row.addView(sw)
        card.addView(row, lp(MATCH, WRAP, 0, 6, 0, 6))
    }

    private fun slider(
        card: LinearLayout, title: String, min: Int, max: Int, cur: Int,
        fmt: (Int) -> String, onChange: (Int) -> Unit
    ) {
        val t = label("$title: ${fmt(cur)}", 14f, Color.argb(220, 255, 255, 255))
        card.addView(t, lp(MATCH, WRAP, 0, 10, 0, 0))
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = cur - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                t.text = "$title: ${fmt(p + min)}"
                if (fromUser) onChange(p + min)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        card.addView(sb, lp(MATCH, WRAP))
    }

    private fun permRow(
        card: LinearLayout, title: String, check: () -> Boolean,
        actionText: String, action: () -> Unit
    ) {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.addView(label(title, 15f))
        val st = label("", 12f, Color.argb(170, 255, 255, 255))
        left.addView(st)
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(button(actionText, false, action))
        card.addView(row, lp(MATCH, WRAP, 0, 8, 0, 8))
        refreshers += {
            val ok = check()
            st.text = if (ok) "✓ Включено" else "Не включено"
            st.setTextColor(if (ok) Color.rgb(48, 209, 88) else Color.rgb(255, 159, 10))
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        val scroll = ScrollView(this)
        scroll.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF0B0B16.toInt(), 0xFF1B1038.toInt(), 0xFF0A2447.toInt())
        )
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(56), dp(18), dp(40))
        scroll.addView(col)
        setContentView(scroll)
        scroll.setOnApplyWindowInsetsListener { _, ins ->
            col.setPadding(dp(18), ins.systemWindowInsetTop + dp(24), dp(18), ins.systemWindowInsetBottom + dp(32))
            ins
        }

        col.addView(label("Glass Home", 34f, Color.WHITE, true))
        col.addView(label("Рабочий стол в стиле iOS 26 • оптимизирован под Honor 90", 14f, Color.argb(190, 255, 255, 255)))

        previewApps = AppRepo.load(this).take(5)

        buildHomeSection(col)
        buildIconSection(col)
        buildIslandSection(col)
        buildWallpaperSection(col)
    }

    override fun onResume() {
        super.onResume()
        refreshers.forEach { it() }
        if (prefs.islandEnabled && Settings.canDrawOverlays(this)) IslandService.start(this)
    }

    // ---------------------------------------------------------------- sections

    private fun isDefaultHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    /** Переход в системные настройки выбора рабочего стола. */
    private fun openHomeSettings() {
        val tries = listOf(
            Intent(Settings.ACTION_HOME_SETTINGS),
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (i in tries) {
            try { startActivity(i); return } catch (e: Exception) { }
        }
        Toast.makeText(this, "Откройте: Настройки → Приложения → Приложения по умолчанию → Рабочий стол", Toast.LENGTH_LONG).show()
    }

    private fun openRoleDialog() {
        try {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 12)
                return
            }
        } catch (e: Exception) { }
        openHomeSettings()
    }

    private fun buildHomeSection(col: LinearLayout) {
        val s = section(col, "Рабочий стол")
        val st = label("", 14f)
        s.addView(st)
        refreshers += {
            val ok = isDefaultHome()
            st.text = if (ok) "✓ Glass Home — рабочий стол по умолчанию"
            else "Сейчас используется другой рабочий стол"
            st.setTextColor(if (ok) Color.rgb(48, 209, 88) else Color.WHITE)
        }
        s.addView(button("Выбрать рабочий стол по умолчанию", true) { openHomeSettings() }, lp(MATCH, WRAP, 0, 12))
        s.addView(button("Быстрый выбор (системный диалог)", false) { openRoleDialog() }, lp(MATCH, WRAP, 0, 8))
    }

    private fun mark(tv: TextView, selected: Boolean) {
        val g = GradientDrawable()
        g.cornerRadius = dp(12).toFloat()
        g.setColor(if (selected) Color.argb(235, 255, 255, 255) else Color.TRANSPARENT)
        tv.background = g
        tv.setTextColor(if (selected) Color.rgb(20, 20, 30) else Color.WHITE)
    }

    private fun segment(text: String): TextView {
        val t = label(text, 14f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(10), 0, dp(10))
        return t
    }

    private fun updateSegments() {
        val glass = prefs.iconStyle == Prefs.STYLE_GLASS
        mark(segGlass, glass)
        mark(segColor, !glass)
        colorBox.visibility = if (glass) View.GONE else View.VISIBLE
        renderPreview()
    }

    private fun renderPreview() {
        previewRow.removeAllViews()
        val size = dp(58)
        for (a in previewApps) {
            val iv = ImageView(this)
            iv.setImageBitmap(IconRenderer.get(a, prefs.iconStyle, prefs.tintColor, size))
            previewRow.addView(iv, LinearLayout.LayoutParams(0, size, 1f))
        }
    }

    private fun buildIconSection(col: LinearLayout) {
        val s = section(col, "Стиль иконок")

        val seg = LinearLayout(this)
        val segBg = GradientDrawable()
        segBg.cornerRadius = dp(14).toFloat()
        segBg.setColor(Color.argb(40, 255, 255, 255))
        seg.background = segBg
        seg.setPadding(dp(3), dp(3), dp(3), dp(3))
        segGlass = segment("Жидкое стекло")
        segColor = segment("Свой цвет")
        seg.addView(segGlass, LinearLayout.LayoutParams(0, WRAP, 1f))
        seg.addView(segColor, LinearLayout.LayoutParams(0, WRAP, 1f))
        s.addView(seg, lp(MATCH, WRAP))

        previewRow = LinearLayout(this)
        previewRow.gravity = Gravity.CENTER
        previewRow.setPadding(dp(8), dp(16), dp(8), dp(16))
        val pbg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF7B2CBF.toInt(), 0xFF0A84FF.toInt(), 0xFFFF9A3D.toInt())
        )
        pbg.cornerRadius = dp(20).toFloat()
        previewRow.background = pbg
        s.addView(previewRow, lp(MATCH, WRAP, 0, 14))

        colorBox = LinearLayout(this)
        colorBox.orientation = LinearLayout.VERTICAL
        s.addView(colorBox, lp(MATCH, WRAP, 0, 10))
        colorBox.addView(label("Цвет иконок", 14f, Color.argb(220, 255, 255, 255)))

        val colors = intArrayOf(
            0xFF0A84FF.toInt(), 0xFF30D158.toInt(), 0xFFFF9F0A.toInt(), 0xFFFF453A.toInt(), 0xFFBF5AF2.toInt(),
            0xFFFF375F.toInt(), 0xFF64D2FF.toInt(), 0xFFFFD60A.toInt(), 0xFF8E8E93.toInt(), 0xFF1C1C1E.toInt()
        )
        for (rowColors in colors.toList().chunked(5)) {
            val row = LinearLayout(this)
            for (c in rowColors) {
                val dot = View(this)
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(c)
                g.setStroke(dp(2), Color.argb(120, 255, 255, 255))
                dot.background = g
                dot.setOnClickListener { prefs.tintColor = c; renderPreview() }
                row.addView(dot, lp(0, dp(36), 4, 4, 4, 4).also { it.width = 0; it.weight = 1f })
            }
            colorBox.addView(row, lp(MATCH, WRAP, 0, 8))
        }

        colorBox.addView(label("Оттенок", 13f, Color.argb(170, 255, 255, 255)), lp(MATCH, WRAP, 0, 10))
        val hue = SeekBar(this)
        hue.max = 360
        val hsv = FloatArray(3)
        Color.colorToHSV(prefs.tintColor, hsv)
        hue.progress = hsv[0].toInt()
        val rainbow = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED)
        )
        rainbow.cornerRadius = dp(6).toFloat()
        hue.progressDrawable = rainbow
        hue.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    prefs.tintColor = Color.HSVToColor(floatArrayOf(p.toFloat(), 0.85f, 0.95f))
                    renderPreview()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        colorBox.addView(hue, lp(MATCH, WRAP, 0, 4))

        segGlass.setOnClickListener { prefs.iconStyle = Prefs.STYLE_GLASS; updateSegments() }
        segColor.setOnClickListener { prefs.iconStyle = Prefs.STYLE_COLOR; updateSegments() }
        updateSegments()
    }

    private fun buildIslandSection(col: LinearLayout) {
        val s = section(col, "Dynamic Island")
        switchRow(s, "Включить Dynamic Island", prefs.islandEnabled) {
            prefs.islandEnabled = it
            if (it && Settings.canDrawOverlays(this)) IslandService.start(this) else IslandService.stop(this)
        }
        switchRow(s, "Показывать капсулу в покое", prefs.islandIdle) { prefs.islandIdle = it }
        slider(s, "Размер", 70, 150, (prefs.islandScale * 100).toInt(), { "$it%" }) { prefs.islandScale = it / 100f }
        slider(s, "Положение по вертикали", -10, 20, prefs.islandOffsetDp.toInt(), { "${it} dp" }) {
            prefs.islandOffsetDp = it.toFloat()
        }
        s.addView(button("Показать пример", true) { runDemo() }, lp(MATCH, WRAP, 0, 14))

        permRow(s, "Поверх других окон", { Settings.canDrawOverlays(this) }, "Открыть") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        permRow(s, "Доступ к уведомлениям", {
            NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        }, "Открыть") {
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { }
        }
        val hint = label(
            "Если переключатель серый (Android 13+): Информация о приложении → ⋮ → «Разрешить ограниченные настройки», затем вернитесь сюда.",
            12f, Color.argb(150, 255, 255, 255)
        )
        s.addView(hint, lp(MATCH, WRAP, 0, 2, 0, 6))
        s.addView(button("Информация о приложении", false) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        permRow(s, "Без ограничений батареи", {
            getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        }, "Открыть") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
            }
        }
        s.addView(
            label("Honor / MagicOS: в Диспетчере телефона разрешите приложению автозапуск и работу в фоне, иначе система может закрывать остров.",
                12f, Color.argb(150, 255, 255, 255)),
            lp(MATCH, WRAP, 0, 4)
        )
    }

    private fun runDemo() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала разрешите «Поверх других окон»", Toast.LENGTH_LONG).show()
            return
        }
        if (!prefs.islandEnabled) prefs.islandEnabled = true
        val svc = IslandService.instance
        if (svc != null) svc.demo()
        else {
            IslandService.start(this)
            window.decorView.postDelayed({ IslandService.instance?.demo() }, 900)
        }
    }

    private fun buildWallpaperSection(col: LinearLayout) {
        val s = section(col, "Обои")
        s.addView(button("Выбрать свои обои", false) {
            val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
            startActivityForResult(i, REQ_WALLPAPER)
        })
        s.addView(button("Сбросить на стандартные", false) {
            File(filesDir, "wallpaper.jpg").delete()
            prefs.wallpaperRev = prefs.wallpaperRev + 1
            Toast.makeText(this, "Обои сброшены", Toast.LENGTH_SHORT).show()
        }, lp(MATCH, WRAP, 0, 8))
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_WALLPAPER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    File(filesDir, "wallpaper.jpg").outputStream().use { input.copyTo(it) }
                }
                prefs.wallpaperRev = prefs.wallpaperRev + 1
                Toast.makeText(this, "Обои установлены", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось загрузить изображение", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
