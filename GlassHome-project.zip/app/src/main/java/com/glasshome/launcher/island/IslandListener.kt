package com.glasshome.launcher.island

import android.app.Notification
import android.app.NotificationManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Получает уведомления и медиа-сессии для Dynamic Island (нужен «Доступ к уведомлениям»). */
class IslandListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        IslandService.instance?.reconnectMedia()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val svc = IslandService.instance ?: return
        val n = sbn.notification ?: return
        if (sbn.packageName == packageName) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0 && n.category != Notification.CATEGORY_CALL) return
        val extras = n.extras ?: return
        val template = extras.getString(Notification.EXTRA_TEMPLATE) ?: ""
        if (template.contains("MediaStyle")) return

        try {
            val rm = Ranking()
            if (currentRanking.getRanking(sbn.key, rm) && rm.importance < NotificationManager.IMPORTANCE_DEFAULT) return
        } catch (e: Exception) { }

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return
        svc.onNotification(title, text, sbn.packageName, n.contentIntent)
    }
}
