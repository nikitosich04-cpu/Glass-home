package com.glasshome.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.ViewOutlineProvider
import java.io.File

/** Обои лаунчера + размытая копия, которую «просвечивают» стеклянные панели. */
object Wallpaper {
    @Volatile var sharp: Bitmap? = null
    @Volatile var blurred: Bitmap? = null
    @Volatile var viewW = 1
    @Volatile var viewH = 1

    fun load(ctx: Context, w: Int, h: Int) {
        val file = File(ctx.filesDir, "wallpaper.jpg")
        var bmp: Bitmap? = null
        if (file.exists()) bmp = decodeCover(file.path, w, h)
        if (bmp == null) bmp = defaultWallpaper(w, h)
        viewW = w
        viewH = h
        blurred = blur(bmp)
        sharp = bmp
    }

    private fun decodeCover(path: String, w: Int, h: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            if (o.outWidth <= 0) return null
            var sample = 1
            while (o.outWidth / (sample * 2) >= w && o.outHeight / (sample * 2) >= h) sample *= 2
            val src = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return null
            val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
            val dw = src.width * scale
            val dh = src.height * scale
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(out).drawBitmap(
                src, null,
                RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f),
                Paint(Paint.FILTER_BITMAP_FLAG)
            )
            out
        } catch (e: Exception) {
            null
        }
    }

    private fun defaultWallpaper(w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF1B1464.toInt(), 0xFF3A1C8C.toInt(), 0xFF0A4DA6.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        blob(c, w * 0.15f, h * 0.18f, w * 0.95f, 0xFFFF4FA3.toInt())
        blob(c, w * 0.95f, h * 0.42f, w * 0.85f, 0xFF29C5FF.toInt())
        blob(c, w * 0.25f, h * 0.78f, w * 1.0f, 0xFFFF9A3D.toInt())
        blob(c, w * 0.9f, h * 0.97f, w * 0.75f, 0xFF7B5BFF.toInt())
        return b
    }

    private fun blob(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        val rgb = color and 0x00FFFFFF
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            x, y, r,
            intArrayOf(rgb or 0xCC000000.toInt(), rgb),
            null, Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, p)
    }

    private fun blur(src: Bitmap): Bitmap {
        val sw = 96
        val sh = (96f * src.height / src.width).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        repeat(3) { boxBlur(px, sw, sh, 3) }
        return Bitmap.createBitmap(px, sw, sh, Bitmap.Config.ARGB_8888)
    }

    private fun boxBlur(px: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(px.size)
        for (y in 0 until h) for (x in 0 until w) {
            var a = 0; var rr = 0; var g = 0; var b = 0; var n = 0
            for (k in -r..r) {
                val p = px[y * w + (x + k).coerceIn(0, w - 1)]
                a += p ushr 24; rr += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; n++
            }
            tmp[y * w + x] = ((a / n) shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (b / n)
        }
        for (y in 0 until h) for (x in 0 until w) {
            var a = 0; var rr = 0; var g = 0; var b = 0; var n = 0
            for (k in -r..r) {
                val p = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                a += p ushr 24; rr += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; n++
            }
            px[y * w + x] = ((a / n) shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (b / n)
        }
    }
}

class WallpaperView(context: Context, private val onReady: () -> Unit) : View(context) {
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        reload()
    }

    fun reload() {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        val app = context.applicationContext
        Thread {
            Wallpaper.load(app, w, h)
            post { invalidate(); onReady() }
        }.start()
    }

    override fun onDraw(canvas: Canvas) {
        val b = Wallpaper.sharp
        if (b != null) canvas.drawBitmap(b, 0f, 0f, null) else canvas.drawColor(Color.BLACK)
    }
}

/**
 * «Жидкое стекло»: размытое/насыщенное содержимое обоев под панелью,
 * светлая дымка, блик сверху и переливающаяся кромка.
 */
class GlassView(
    context: Context,
    private val cornerDp: Float = -1f,
    private val strength: Float = 1f,
    shadow: Boolean = false
) : View(context) {
    private val d = resources.displayMetrics.density
    private val loc = IntArray(2)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val m = Matrix()
    private val rect = RectF()
    private var shader: BitmapShader? = null
    private var shaderFor: Bitmap? = null
    private val sat = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1.6f) })

    private fun radius(): Float = if (cornerDp < 0f) height / 2f else cornerDp * d

    init {
        rim.style = Paint.Style.STROKE
        rim.strokeWidth = 1.4f * d
        if (shadow) {
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius())
                    outline.alpha = 0.35f
                }
            }
            elevation = 8f * d
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val a = (80 * strength).toInt().coerceIn(0, 255)
        shine.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(
                Color.argb(a, 255, 255, 255), Color.argb(0, 255, 255, 255),
                Color.argb(0, 255, 255, 255), Color.argb(a / 3, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.45f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        rim.shader = LinearGradient(
            0f, 0f, w.toFloat(), h.toFloat(),
            intArrayOf(
                Color.argb(220, 255, 255, 255), Color.argb(25, 255, 255, 255),
                Color.argb(25, 255, 255, 255), Color.argb(150, 255, 255, 255)
            ),
            floatArrayOf(0f, 0.35f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = radius()
        rect.set(0f, 0f, w, h)

        val bm = Wallpaper.blurred
        if (bm != null) {
            if (shaderFor !== bm) {
                shader = BitmapShader(bm, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                shaderFor = bm
            }
            getLocationInWindow(loc)
            m.reset()
            m.setScale(Wallpaper.viewW.toFloat() / bm.width, Wallpaper.viewH.toFloat() / bm.height)
            m.postTranslate(-loc[0].toFloat(), -loc[1].toFloat())
            shader?.setLocalMatrix(m)
            fill.shader = shader
            fill.colorFilter = sat
            canvas.drawRoundRect(rect, r, r, fill)
        }
        fill.shader = null
        fill.colorFilter = null
        fill.color = Color.argb((46 * strength).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawRoundRect(rect, r, r, fill)
        canvas.drawRoundRect(rect, r, r, shine)
        val inset = rim.strokeWidth / 2f
        rect.set(inset, inset, w - inset, h - inset)
        canvas.drawRoundRect(rect, r - inset, r - inset, rim)
    }
}
