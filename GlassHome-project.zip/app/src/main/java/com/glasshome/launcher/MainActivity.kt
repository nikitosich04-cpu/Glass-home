package com.glasshome.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.glasshome.launcher.island.IslandService
import java.util.concurrent.Executors
import kotlin.math.abs

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var wallpaperView: WallpaperView
    private lateinit var pager: ViewPager2
    private lateinit var indicator: PageIndicator
    private lateinit var dockHolder: FrameLayout
    private val adapter = PagesAdapter()

    private var overlay: View? = null
    private var apps: List<AppInfo> = emptyList()
    private var dockApps: List<AppInfo> = emptyList()
    private var pages: List<List<AppInfo>> = emptyList()

    private var topInset = 0
    private var bottomInset = 0
    private var iconSize = 0
    private var miniSize = 0
    private var dockH = 0
    private var cols = 4
    private var rows = 6
    private var sidePad = 0
    private var builtKey = ""
    private var lastWallRev = -1
    private var lastLayoutKey = ""
    private val worker = Executors.newSingleThreadExecutor()

    private val dens: Float get() = resources.displayMetrics.density
    private fun dp(v: Number): Int = (v.toFloat() * dens).toInt()

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        buildUi()
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_CHANGED)
        f.addDataScheme("package")
        ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        if (prefs.islandEnabled && Settings.canDrawOverlays(this)) IslandService.start(this)
        if (iconSize > 0 && builtKey != "${prefs.signature()}-$iconSize") reloadAll()
        if (lastWallRev != prefs.wallpaperRev) {
            lastWallRev = prefs.wallpaperRev
            wallpaperView.reload()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        closeOverlay()
        if (::pager.isInitialized) pager.setCurrentItem(0, true)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (overlay != null) closeOverlay()
        else if (pager.currentItem != 0) pager.setCurrentItem(0, true)
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { reloadAll() }
    }

    private val gestures by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || overlay != null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (dy > dp(90) && vy > 900 && abs(dy) > abs(dx) * 1.6f && pager.currentItem < pages.size) {
                    openSearch()
                }
                return false
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        root = FrameLayout(this)
        root.clipChildren = false

        wallpaperView = WallpaperView(this) { invalidateGlass(root) }
        root.addView(wallpaperView, FrameLayout.LayoutParams(MATCH, MATCH))

        pager = ViewPager2(this)
        pager.adapter = adapter
        pager.offscreenPageLimit = 1
        (pager.getChildAt(0) as RecyclerView).overScrollMode = View.OVER_SCROLL_NEVER
        root.addView(pager, FrameLayout.LayoutParams(MATCH, MATCH))

        indicator = PageIndicator(this) { openSearch() }
        root.addView(indicator, FrameLayout.LayoutParams(dp(132), dp(32), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))

        dockHolder = FrameLayout(this)
        root.addView(dockHolder, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                indicator.setPosition(position + positionOffset)
            }
        })

        root.setOnApplyWindowInsetsListener { _, insets ->
            onInsets(insets)
            insets
        }
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, oR, ob ->
            if (r - l != oR - ol || b - t != ob - ot) relayout()
        }
        setContentView(root)
    }

    @Suppress("DEPRECATION")
    private fun onInsets(insets: WindowInsets) {
        topInset = insets.systemWindowInsetTop
        bottomInset = insets.systemWindowInsetBottom
        detectCutout(insets)
        relayout()
    }

    /** Запоминаем позицию выреза камеры — по ней ставится Dynamic Island. */
    private fun detectCutout(insets: WindowInsets) {
        val dc = insets.displayCutout ?: return
        val r = dc.boundingRects.firstOrNull { it.top <= 2 && it.width() > 0 } ?: return
        if (abs(prefs.cutoutCy - r.exactCenterY()) > 0.5f) prefs.cutoutCy = r.exactCenterY()
        if (abs(prefs.cutoutH - r.height()) > 0.5f) prefs.cutoutH = r.height().toFloat()
        if (abs(prefs.cutoutW - r.width()) > 0.5f) prefs.cutoutW = r.width().toFloat()
    }

    private fun relayout() {
        val w = root.width
        val h = root.height
        if (w <= 0 || h <= 0) return
        sidePad = dp(10)
        val cellW = (w - 2 * sidePad) / cols
        iconSize = minOf((cellW * 0.64f).toInt(), dp(76))
        dockH = iconSize + dp(24)
        val dockBottom = maxOf(bottomInset, dp(8)) + dp(4)
        val indBottom = dockBottom + dockH + dp(8)
        val pagerTop = topInset + dp(6)
        val pagerBottom = indBottom + dp(32) + dp(6)
        rows = ((h - pagerTop - pagerBottom) / (iconSize + dp(34))).coerceIn(3, 6)
        val cardW = (w - dp(40) - dp(16)) / 2
        miniSize = (cardW - 3 * (cardW * 0.1f).toInt()) / 2

        val key = "$w,$h,$topInset,$bottomInset,$iconSize,$rows"
        if (key == lastLayoutKey) return
        lastLayoutKey = key

        val pl = pager.layoutParams as FrameLayout.LayoutParams
        pl.topMargin = pagerTop; pl.bottomMargin = pagerBottom
        pager.layoutParams = pl
        val il = indicator.layoutParams as FrameLayout.LayoutParams
        il.bottomMargin = indBottom
        indicator.layoutParams = il
        val dl = dockHolder.layoutParams as FrameLayout.LayoutParams
        dl.bottomMargin = dockBottom
        dockHolder.layoutParams = dl
        reloadAll()
    }

    private fun invalidateGlass(v: View) {
        if (v is GlassView) v.invalidate()
        if (v is ViewGroup) for (i in 0 until v.childCount) invalidateGlass(v.getChildAt(i))
    }

    // ---------------------------------------------------------------- data

    private fun reloadAll() {
        val size = iconSize
        if (size <= 0) return
        val style = prefs.iconStyle
        val tint = prefs.tintColor
        val mini = miniSize
        val small = dp(44)
        worker.execute {
            val list = AppRepo.load(this)
            for (a in list) IconRenderer.get(a, style, tint, size)
            runOnUiThread {
                apps = list
                builtKey = "${prefs.signature()}-$size"
                applyApps()
            }
            for (a in list) {
                IconRenderer.get(a, style, tint, mini)
                IconRenderer.get(a, style, tint, small)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveDock(): List<AppInfo> {
        val saved = prefs.dock
        if (saved != null) {
            return saved.split(",").mapNotNull { k -> apps.firstOrNull { it.key == k } }.take(4)
        }
        val pm = packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        val out = mutableListOf<AppInfo>()
        for (i in intents) {
            val ri = pm.resolveActivity(i, 0) ?: continue
            val a = apps.firstOrNull { it.pkg == ri.activityInfo.packageName } ?: continue
            if (out.none { it.pkg == a.pkg }) out.add(a)
        }
        return out
    }

    private fun applyApps() {
        dockApps = resolveDock()
        val rest = apps.filter { a -> dockApps.none { it.key == a.key } }
        val per = cols * rows
        pages = if (rest.isEmpty()) listOf(emptyList()) else rest.chunked(per)
        adapter.notifyDataSetChanged()
        indicator.setCount(pages.size + 1)
        rebuildDock()
    }

    private fun saveDock(list: List<AppInfo>) {
        prefs.dock = list.joinToString(",") { it.key }
        applyApps()
    }

    private fun rebuildDock() {
        dockHolder.removeAllViews()
        val w = root.width
        if (w <= 0) return
        val style = prefs.iconStyle
        val tint = prefs.tintColor
        val pill = FrameLayout(this)
        pill.addView(GlassView(this, 34f, 1.2f, true), FrameLayout.LayoutParams(MATCH, MATCH))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(sidePad, 0, sidePad, 0)
        for (a in dockApps) {
            row.addView(
                makeCell(a, IconRenderer.get(a, style, tint, iconSize), iconSize, false, true),
                LinearLayout.LayoutParams(0, MATCH, 1f)
            )
        }
        for (i in dockApps.size until 4) row.addView(View(this), LinearLayout.LayoutParams(0, MATCH, 1f))
        pill.addView(row, FrameLayout.LayoutParams(MATCH, MATCH))
        dockHolder.addView(pill, FrameLayout.LayoutParams(w - 2 * sidePad, dockH, Gravity.CENTER_HORIZONTAL))
    }

    private fun makeCell(app: AppInfo, icon: Bitmap, size: Int, label: Boolean, inDock: Boolean): AppCell {
        val c = AppCell(this, app, icon, size, label)
        c.setOnClickListener { launch(app, c.iconView) }
        c.setOnLongClickListener { showAppMenu(app, c, inDock); true }
        return c
    }

    private fun launch(app: AppInfo, from: View?) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            if (from != null) {
                val o = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
                startActivity(i, o.toBundle())
            } else startActivity(i)
            if (overlay != null) closeOverlay()
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть приложение", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openSettings() = startActivity(Intent(this, SettingsActivity::class.java))

    // ---------------------------------------------------------------- pager

    private inner class PagesAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount(): Int = pages.size + 1
        override fun getItemViewType(position: Int): Int = if (position < pages.size) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val v: View = if (viewType == 0) GridPage(this@MainActivity) else LibraryPage(this@MainActivity)
            v.layoutParams = RecyclerView.LayoutParams(MATCH, MATCH)
            return object : RecyclerView.ViewHolder(v) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val v = holder.itemView
            if (v is GridPage) bindGrid(v, pages[position])
            else if (v is LibraryPage) bindLibrary(v)
        }
    }

    private fun bindGrid(page: GridPage, list: List<AppInfo>) {
        page.cols = cols
        page.rows = rows
        page.sidePad = sidePad
        page.removeAllViews()
        val style = prefs.iconStyle
        val tint = prefs.tintColor
        for (a in list) {
            page.addView(makeCell(a, IconRenderer.get(a, style, tint, iconSize), iconSize, true, false))
        }
        page.setOnLongClickListener { openSettings(); true }
    }

    private fun bindLibrary(page: LibraryPage) {
        val c = page.content
        c.removeAllViews()
        val w = root.width
        if (w <= 0) return
        c.setPadding(dp(20), dp(8), dp(20), dp(24))

        val search = FrameLayout(this)
        search.addView(GlassView(this, -1f, 1.2f), FrameLayout.LayoutParams(MATCH, MATCH))
        val st = TextView(this)
        st.text = "Библиотека приложений"
        st.setTextColor(Color.argb(200, 255, 255, 255))
        st.textSize = 16f
        st.gravity = Gravity.CENTER
        search.addView(st, FrameLayout.LayoutParams(MATCH, MATCH))
        search.setOnClickListener { openSearch() }
        c.addView(search, LinearLayout.LayoutParams(MATCH, dp(46)))

        val cardW = (w - dp(40) - dp(16)) / 2
        val groups = apps.groupBy { AppRepo.group(it) }
        val entries = AppRepo.groupOrder.mapNotNull { n -> groups[n]?.let { n to it } }
        for (pair in entries.chunked(2)) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for ((idx, e) in pair.withIndex()) {
                val lp = LinearLayout.LayoutParams(cardW, WRAP)
                if (idx == 0) lp.marginEnd = dp(16)
                r.addView(libraryCard(e.first, e.second, cardW), lp)
            }
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(18)
            c.addView(r, lp)
        }
    }

    private fun libraryCard(name: String, list: List<AppInfo>, cardW: Int): View {
        val style = prefs.iconStyle
        val tint = prefs.tintColor
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val card = FrameLayout(this)
        val glass = GlassView(this, 24f, 1.1f)
        card.addView(glass, FrameLayout.LayoutParams(MATCH, MATCH))
        card.setOnClickListener { showCategory(name, list) }
        val pad = (cardW * 0.1f).toInt()
        val mini = (cardW - 3 * pad) / 2
        for ((i, a) in list.take(4).withIndex()) {
            val iv = ImageView(this)
            iv.setImageBitmap(IconRenderer.get(a, style, tint, mini))
            iv.setOnClickListener { launch(a, iv) }
            val lp = FrameLayout.LayoutParams(mini, mini)
            lp.leftMargin = pad + (i % 2) * (mini + pad)
            lp.topMargin = pad + (i / 2) * (mini + pad)
            card.addView(iv, lp)
        }
        col.addView(card, LinearLayout.LayoutParams(cardW, cardW))
        val t = TextView(this)
        t.text = name
        t.setTextColor(Color.WHITE)
        t.textSize = 12.5f
        t.gravity = Gravity.CENTER
        t.setShadowLayer(4 * dens, 0f, dens, Color.argb(150, 0, 0, 0))
        val tl = LinearLayout.LayoutParams(MATCH, WRAP)
        tl.topMargin = dp(6)
        col.addView(t, tl)
        return col
    }

    // ---------------------------------------------------------------- overlays

    private fun showOverlay(v: View, blur: Boolean) {
        if (overlay != null) closeOverlay()
        overlay = v
        v.alpha = 0f
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        v.animate().alpha(1f).setDuration(180).start()
        if (blur) setBlur(true)
    }

    private fun closeOverlay() {
        val v = overlay ?: return
        overlay = null
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0)
        setBlur(false)
        v.animate().alpha(0f).setDuration(140).withEndAction { root.removeView(v) }.start()
    }

    private fun setBlur(on: Boolean) {
        if (Build.VERSION.SDK_INT < 31) return
        val fx = if (on) RenderEffect.createBlurEffect(40f, 40f, Shader.TileMode.CLAMP) else null
        wallpaperView.setRenderEffect(fx)
        pager.setRenderEffect(fx)
        dockHolder.setRenderEffect(fx)
        indicator.setRenderEffect(fx)
    }

    private fun scrim(alpha: Int): View {
        val s = View(this)
        s.setBackgroundColor(Color.argb(alpha, 6, 8, 18))
        s.setOnClickListener { closeOverlay() }
        return s
    }

    private fun openSearch() {
        if (overlay != null) return
        val style = prefs.iconStyle
        val tint = prefs.tintColor
        val layer = FrameLayout(this)
        layer.addView(scrim(120), FrameLayout.LayoutParams(MATCH, MATCH))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), topInset + dp(14), dp(16), 0)

        val field = FrameLayout(this)
        field.addView(GlassView(this, -1f, 1.4f), FrameLayout.LayoutParams(MATCH, MATCH))
        val edit = EditText(this)
        edit.hint = "Поиск"
        edit.setHintTextColor(Color.argb(150, 255, 255, 255))
        edit.setTextColor(Color.WHITE)
        edit.textSize = 17f
        edit.background = null
        edit.isSingleLine = true
        edit.imeOptions = EditorInfo.IME_ACTION_SEARCH
        edit.setPadding(dp(20), 0, dp(20), 0)
        field.addView(edit, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(field, LinearLayout.LayoutParams(MATCH, dp(50)))

        val card = FrameLayout(this)
        card.addView(GlassView(this, 24f, 1.6f), FrameLayout.LayoutParams(MATCH, MATCH))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(6), 0, dp(6))
        card.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        val sv = ScrollView(this)
        sv.addView(card, ViewGroup.LayoutParams(MATCH, WRAP))
        val svLp = LinearLayout.LayoutParams(MATCH, WRAP)
        svLp.topMargin = dp(12)
        col.addView(sv, svLp)

        var first: AppInfo? = null
        fun refresh(q: String) {
            list.removeAllViews()
            val res = if (q.isBlank()) apps.take(8)
            else apps.filter { it.label.contains(q.trim(), ignoreCase = true) }.take(10)
            first = res.firstOrNull()
            card.visibility = if (res.isEmpty()) View.GONE else View.VISIBLE
            for (a in res) {
                val row = LinearLayout(this)
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(16), dp(8), dp(16), dp(8))
                val iv = ImageView(this)
                iv.setImageBitmap(IconRenderer.get(a, style, tint, dp(44)))
                row.addView(iv, LinearLayout.LayoutParams(dp(44), dp(44)))
                val tv = TextView(this)
                tv.text = a.label
                tv.setTextColor(Color.WHITE)
                tv.textSize = 17f
                val tl = LinearLayout.LayoutParams(WRAP, WRAP)
                tl.marginStart = dp(14)
                row.addView(tv, tl)
                row.setOnClickListener { launch(a, iv) }
                list.addView(row)
            }
        }
        edit.doAfterTextChanged { refresh(it?.toString() ?: "") }
        edit.setOnEditorActionListener { _, _, _ ->
            val f = first
            if (f != null) launch(f, null)
            true
        }
        refresh("")
        layer.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        showOverlay(layer, true)
        edit.requestFocus()
        edit.postDelayed({
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(edit, InputMethodManager.SHOW_IMPLICIT)
        }, 220)
    }

    private fun showCategory(name: String, list: List<AppInfo>) {
        val style = prefs.iconStyle
        val tint = prefs.tintColor
        val layer = FrameLayout(this)
        layer.addView(scrim(130), FrameLayout.LayoutParams(MATCH, MATCH))
        val panel = FrameLayout(this)
        panel.addView(GlassView(this, 30f, 1.6f), FrameLayout.LayoutParams(MATCH, MATCH))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), dp(18), dp(8), dp(14))
        val title = TextView(this)
        title.text = name
        title.setTextColor(Color.WHITE)
        title.textSize = 20f
        title.gravity = Gravity.CENTER
        col.addView(title, LinearLayout.LayoutParams(MATCH, WRAP))
        val sv = ScrollView(this)
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        val size = (iconSize * 0.9f).toInt()
        for (chunk in list.chunked(4)) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (a in chunk) {
                r.addView(
                    makeCell(a, IconRenderer.get(a, style, tint, size), size, true, false),
                    LinearLayout.LayoutParams(0, size + dp(34), 1f)
                )
            }
            for (i in chunk.size until 4) r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            grid.addView(r)
        }
        sv.addView(grid, ViewGroup.LayoutParams(MATCH, WRAP))
        val svLp = LinearLayout.LayoutParams(MATCH, WRAP)
        svLp.topMargin = dp(10)
        col.addView(sv, svLp)
        panel.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        val maxH = (root.height * 0.62f).toInt()
        val pl = FrameLayout.LayoutParams(root.width - dp(32), WRAP, Gravity.CENTER)
        pl.height = minOf(maxH, (list.chunked(4).size * (size + dp(34))) + dp(80))
        layer.addView(panel, pl)
        showOverlay(layer, true)
    }

    private fun showAppMenu(app: AppInfo, cell: AppCell, inDock: Boolean) {
        val style = prefs.iconStyle
        val tint = prefs.tintColor
        val layer = FrameLayout(this)
        val dim = View(this)
        dim.setBackgroundColor(Color.argb(90, 0, 0, 0))
        dim.setOnClickListener { closeOverlay() }
        layer.addView(dim, FrameLayout.LayoutParams(MATCH, MATCH))

        val loc = IntArray(2)
        cell.iconView.getLocationInWindow(loc)
        val iv = ImageView(this)
        iv.setImageBitmap(IconRenderer.get(app, style, tint, iconSize))
        val ilp = FrameLayout.LayoutParams(iconSize, iconSize)
        ilp.leftMargin = loc[0]
        ilp.topMargin = loc[1]
        layer.addView(iv, ilp)
        iv.animate().scaleX(1.08f).scaleY(1.08f).setDuration(160).start()

        val menu = LinearLayout(this)
        menu.orientation = LinearLayout.VERTICAL
        val card = FrameLayout(this)
        card.addView(GlassView(this, 20f, 1.8f), FrameLayout.LayoutParams(MATCH, MATCH))
        card.addView(menu, FrameLayout.LayoutParams(MATCH, WRAP))
        var count = 0

        fun addItem(text: String, red: Boolean = false, action: () -> Unit) {
            if (menu.childCount > 0) {
                val sep = View(this)
                sep.setBackgroundColor(Color.argb(40, 255, 255, 255))
                menu.addView(sep, LinearLayout.LayoutParams(MATCH, 1))
            }
            val tv = TextView(this)
            tv.text = text
            tv.textSize = 16f
            tv.setTextColor(if (red) Color.rgb(255, 99, 90) else Color.WHITE)
            tv.gravity = Gravity.CENTER_VERTICAL
            tv.setPadding(dp(18), 0, dp(18), 0)
            tv.setOnClickListener { closeOverlay(); action() }
            menu.addView(tv, LinearLayout.LayoutParams(MATCH, dp(50)))
            count++
        }

        addItem("Информация о приложении") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
        }
        if (inDock) {
            addItem("Убрать из Dock") { saveDock(dockApps.filter { it.key != app.key }) }
        } else if (dockApps.size < 4) {
            addItem("Добавить в Dock") { saveDock(dockApps + app) }
        }
        addItem("Настройки лаунчера") { openSettings() }
        addItem("Удалить приложение", true) {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        }

        val menuW = dp(250)
        val menuH = count * dp(50) + count
        val x = (loc[0] + iconSize / 2 - menuW / 2).coerceIn(dp(16), root.width - menuW - dp(16))
        val below = loc[1] + iconSize + dp(14) + menuH < root.height - bottomInset - dp(16)
        val y = if (below) loc[1] + iconSize + dp(14) else loc[1] - menuH - dp(14)
        val clp = FrameLayout.LayoutParams(menuW, WRAP)
        clp.leftMargin = x
        clp.topMargin = y
        layer.addView(card, clp)
        card.pivotX = (loc[0] + iconSize / 2f - x)
        card.pivotY = (loc[1] + iconSize / 2f - y)
        card.scaleX = 0.5f
        card.scaleY = 0.5f
        card.alpha = 0f
        showOverlay(layer, true)
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(260)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
    }
}
